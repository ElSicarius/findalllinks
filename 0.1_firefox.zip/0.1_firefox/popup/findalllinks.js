var mode = null;

const loadConfig = () => {
	browser.storage.local.get().then((res) => {
		mode = res;
	});
}

const updateConfig = (clipboardState) => {
	browser.storage.local.set(
	{
		FALOutput: clipboardState,
	});
    loadConfig();
}

loadConfig();

document.getElementById("clipboardRb").addEventListener('change', function () {
	if(this.checked) updateConfig("clip");
});
document.getElementById("windowRb").addEventListener('change', function () {
	if(this.checked)updateConfig("window");
});
const get_radio = () => {
    return mode["FALOutput"];
}

document.addEventListener("click", async (e) => {

	switch (e.target.id) {
		case "find_links":
			chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
				chrome.tabs.sendMessage(tabs[0].id, {command: "find_links", mode: get_radio()}, function(response) {
					console.log("Call to function");
				});
			});
			break;

		case "find_paths":
			chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
				chrome.tabs.sendMessage(tabs[0].id, {command: "find_paths", mode: get_radio()}, function(response) {
					console.log("Call to function");
				});
			});
			break;

		case "jslinkfinder":
			chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
				chrome.tabs.sendMessage(tabs[0].id, {command: "jslinkfinder", mode: get_radio()}, function(response) {
					console.log("Call to function");
				});
			});
			break;

		default:
			break;
	}
});
